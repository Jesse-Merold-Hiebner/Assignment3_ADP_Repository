package za.ac.cput.assignment3project;

import java.io.*;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.nio.file.StandardOpenOption;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;

/*
 * @author JESSE HIEBNER
 * 220357676
 */
public class Operations 
{
    //Global Variables:
    private static ObjectInputStream MyInput;
    
    static Customer MyCustomer;
    static Supplier MySupplier;
    
    static Object x; //either customer or supplier record. 
           
    static ArrayList <Customer> MyCustomerList = new ArrayList<> ();  //creating the customer arraylist
    static ArrayList <Supplier> MySupplierList = new ArrayList<> ();  //creating the supplier arraylist
    
    
    public static void OpenStakeholderFile()
    {   // Step 2(a) Read values from serialized file into 2 array lists:  
        try
        {
           MyInput = new ObjectInputStream(new FileInputStream("stakeholder.ser"));
        }
        catch(IOException ioe)
        {
             System.out.println("Error opening .ser file: " + ioe.getMessage());
        }
    }
    
    public static void CloseStakeholderFile()
    {
        try
        {
            MyInput.close();
        }
        catch (IOException ioe) 
        {
            System.out.println("error closing .ser file: " + ioe.getMessage());
        }
    }
    
    //Read Serialized File:    
    public static void ReadFromStakeholderFile()
    {   
       String HolderId;
       String Firstname;
       String Surname;
       String Address;
       String DateOfBirth;
       double Credit;
       boolean CanRent;   //true - can rent a car; false - not allowed to rent because they have not returned a previously rented car
        
        try
        {       
            while(true)
            {                
              x = (Object)MyInput.readObject();
              String y = x.toString();             
              String FirstCharacter = y.substring(0, 1);
              if (FirstCharacter.equalsIgnoreCase("C"))
              {
                   MyCustomer = (Customer)x;
                  MyCustomerList.add(MyCustomer);                   
               }
                //Else condition will store all suppliers records in the supplier list.
               else
               {
                  MySupplier = (Supplier)x; 
                  MySupplierList.add(MySupplier);  
               }//end of if

 
            }//end of while
        }
        catch (ClassNotFoundException ioe)
        {
            System.out.println("class error reading .ser files: " + ioe);
        }
        catch (IOException ioe)
        {
            System.out.println("error reading from .ser file: " + ioe);
        }
        finally
        {
            CloseStakeholderFile();
            System.out.println(" *** File Has Been Closed ***");
        }
    }
    
    private static void SortCustomers()
    {
     // Sort Customers based on their StakeholderID
           
        Customer ThisCustomer, NextCustomer;

        for(int i=0; i < (MyCustomerList.size()-1); i++)
        {
            for(int j=0; j < (MyCustomerList.size()-1); j++)
            {
                ThisCustomer = MyCustomerList.get(j);
                NextCustomer = MyCustomerList.get(j+1);

                if ( ThisCustomer.getStHolderId().compareTo(NextCustomer.getStHolderId()) > 0 )  // current ID is bigger than the next ID…therefore swop the two
                {
                    MyCustomerList.set(j,   NextCustomer);
                    MyCustomerList.set(j+1, ThisCustomer);
                }
            }
        }
        
        
        
    }
    
    private static void DetermineTheAgeOfCustomers()
    {     
        int Age;        
        Customer ThisCustomer;
        
        System.out.println("\nThese are the Customers: \n ");
        for (int i = 0; i < MyCustomerList.size(); i++) 
        {
            ThisCustomer = MyCustomerList.get(i);            
            Age = DetermineTheAge(ThisCustomer.getDateOfBirth());        
            
            System.out.println( ThisCustomer + " and the age is: " + Age );
        }
    }
    
    private static int DetermineTheAge(String DateOfBirth)
    {  
        //This function returns the age as an integer given the date of birth as a string.
        int Year = Calendar.getInstance().get(Calendar.YEAR);
        String YearOfBirth;        
        int Age = 0;
        int NumericYearOfBirth;           
       
        YearOfBirth = DateOfBirth.substring(0,4);
        //Parse year of birth to integer:
        NumericYearOfBirth = Integer.parseInt(YearOfBirth);
        Age = Year - NumericYearOfBirth; 
        
        return Age;
    }
        
    private static void ReformatTheDate()
    {
        Customer ThisCustomer ;
        String ReformattedDate;
        
        System.out.println("\nThese are the Customers with reformatted dates of birth: \n ");           
       
            for (int i = 0; i < MyCustomerList.size(); i++)
            {
                ThisCustomer = MyCustomerList.get(i);                      
                ReformattedDate = ReformatTheDOB(ThisCustomer.getDateOfBirth());
                
                //Display all customers with their reformatted date of birth:
                 System.out.println( ThisCustomer + " and the reformatted date of birth is: " + ReformattedDate );
            }       
    }     
    
    
    private static String ReformatTheDOB(String DateOfBirth)
    {   
        String ReformattedDate = "";
        SimpleDateFormat MyInputDateFormatter = new SimpleDateFormat("yyyy-MM-dd"); //Input format of the date.
        SimpleDateFormat MyOutputDateFormatter = new SimpleDateFormat("dd MMM yyyy"); //Output format of the date.
        Date TrueDate;
                
       try
       {                      
                TrueDate = MyInputDateFormatter.parse(DateOfBirth);
                ReformattedDate = MyOutputDateFormatter.format(TrueDate);  
       }
       
       catch(ParseException ioe)
       {
           System.out.println("Unable to parse Date of Birth" + ioe.getMessage());
       }
       
       return ReformattedDate;
    }  
    
    
   private static void WriteCustomersToFile() 
     {     
        try
        {
            
            Customer ThisCustomer;  
            String NiceDate; 
            int Age;
            
            FileWriter WriteToFile = new FileWriter("CustomerOutFile.txt"); //Created the file
            BufferedWriter MyBufWriter = new BufferedWriter(WriteToFile);
            MyBufWriter.write("=============================== CUSTOMERS ================================\n");
            MyBufWriter.write(String.format("%-10s\t%-15s\t%-15s\t%-15s\t%-15s" , 
                                       "ID", "Name", "Surname", "Date Of Birth", "Age"));
            MyBufWriter.write("\n==========================================================================\n");
            for (int i = 0; i < MyCustomerList.size(); i++) 
            {
                ThisCustomer = MyCustomerList.get(i);            
                 Age = DetermineTheAge(ThisCustomer.getDateOfBirth()); 
                 NiceDate = ReformatTheDOB(ThisCustomer.getDateOfBirth()); //getting formatted DOB             
                
                MyBufWriter.write(String.format("%-10s\t%-15s\t%-15s\t%-15s\t%-15d\n" , 
                                       ThisCustomer.getStHolderId(), ThisCustomer.getFirstName(), ThisCustomer.getSurName(), 
                                       NiceDate, Age ));           
            }
               System.out.println("The Customers were written successfully.");
               MyBufWriter.close();
        }//end of try
        catch(IOException ioe)
             {
                 System.out.println("Error writing customers to file" + ioe.getMessage());
             }
       }                 
       
    //determine the number of customers who can and cannot rent 
    private static void DetermineNumOfCustomersWhoCanAndCannot() 
    {         
       try
       {
            int CustomersWhoCan = 0;
            int CustomersWhoCannot = 0;
            Boolean getCanOrCannot;
            Customer ThisCustomer;   
            String RentComment = "";        
                    
            System.out.println("\nThese are the Customers: \n ");
            for (int i = 0; i < MyCustomerList.size(); i++)
            {
                ThisCustomer = MyCustomerList.get(i);
                getCanOrCannot = ThisCustomer.getCanRent();
                if (getCanOrCannot == true)
                {
                    CustomersWhoCan++;                                  
                }
                else
                {
                    CustomersWhoCannot++;                  
                }                
            }   
            
            RentComment = "\nNumber of customers who can rent: " + CustomersWhoCan;
            Files.write(Paths.get("CustomerOutFile.txt"), RentComment.getBytes(), StandardOpenOption.APPEND);
            
            RentComment = "\nNumber of customers who cannot rent: " + CustomersWhoCannot;
            Files.write(Paths.get("CustomerOutFile.txt"), RentComment.getBytes(), StandardOpenOption.APPEND);     
            
            System.out.println("Wrote the customers who can and cannot rent, to the file");
            
       }//end of try
       catch (IOException ex)
       {
          System.out.println("Cannot write customers who can/can't rent to file" + ex.getMessage());
       }  
    }
    
    private static void SortSuppliers()
    {
     // Sort Customers based on their StakeholderID
           
        Supplier ThisSupplier, NextSupplier;

        for(int i=0; i < (MySupplierList.size()-1); i++)
        {
            for(int j=0; j < (MySupplierList.size()-1); j++)
            {
                ThisSupplier = MySupplierList.get(j);
                NextSupplier = MySupplierList.get(j+1);

                if ( ThisSupplier.getName().compareTo(NextSupplier.getName()) > 0 )  // name is bigger than the next name…therefore swop the two
                {
                    MySupplierList.set(j,   NextSupplier);
                    MySupplierList.set(j+1, ThisSupplier);
                }
            }
        }
    }//End of Sort Suppliers
    
    
    
    //Write suppliers to file
    private static void WriteSuppliersToFile() 
    {     
       try 
       {            
            Supplier ThisSupplier;
            FileWriter WriteToFile = new FileWriter("SupplierOutFile.txt"); //Created the supplier file
            BufferedWriter MyBufWriter = new BufferedWriter(WriteToFile);     
            MyBufWriter.write("=============================== SUPPLIERS ================================\n");
            MyBufWriter.write(String.format("%-5s\t%-20s\t%-10s\t%-15s" , "ID", "Name", "Product Type", "Description") );
            MyBufWriter.write("\n==========================================================================\n");
            String x;
            
            for (int i = 0; i < MySupplierList.size(); i++)
            {
                 ThisSupplier = MySupplierList.get(i);     
                x = ThisSupplier.toString();
                MyBufWriter.write(x + "\n");
            }           
            MyBufWriter.close();             
            System.out.println("The Suppliers were written successfully.");
       } 
       catch (IOException ex) 
       {
            System.out.println("There was an error at writing to suppliers: " + ex.getMessage());
       }
    }            
       
    
    
    public static void main(String[] args) 
    {           
       // Step 2(a) Read values from serialized file into 2 array lists:        
       OpenStakeholderFile();             
       ReadFromStakeholderFile();   
       
        //Step 2(b) Sort the contents of the customer arraylist in ascending order of stakeholderId.
       SortCustomers();
       
       //Step 2(c) Determine the age of each customer and display them.
       DetermineTheAgeOfCustomers();
       
       //Step 2(d) Re-format the date-of-birth: (yyyy-MM-dd to dd MMM yyyy) and display them.
       ReformatTheDate();
       
       //Step 2(e) Write the Customers information to a text file
       WriteCustomersToFile();
       
      //Step 2(f) Determine the number of customers who can or cannot rent and write it to the file.
      DetermineNumOfCustomersWhoCanAndCannot();
      
      //Step 3(a) Sort the contents of supplier in ascending order of name:
      SortSuppliers();
     
      //Step 3(b) Write the details (sorted) of each supplier to another text file (supplierOutFile.txt), including appropriate headings. 
      WriteSuppliersToFile();
      
    } //end of MAIN
//    
    
} // end of Operations
